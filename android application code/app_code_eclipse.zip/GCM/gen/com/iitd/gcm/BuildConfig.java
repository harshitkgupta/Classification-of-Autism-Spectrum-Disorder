/** Automatically generated file. DO NOT MODIFY */
package com.iitd.gcm;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}